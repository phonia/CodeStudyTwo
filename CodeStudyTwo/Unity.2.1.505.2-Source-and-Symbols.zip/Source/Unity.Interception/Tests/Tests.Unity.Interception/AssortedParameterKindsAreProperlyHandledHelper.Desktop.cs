﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.Practices.Unity.InterceptionExtension.Tests
{
    public static partial class AssortedParameterKindsAreProperlyHandledHelper
    {
        public partial class TypeWithAssertedParameterKinds : MarshalByRefObject
        {
        }
    }
}
