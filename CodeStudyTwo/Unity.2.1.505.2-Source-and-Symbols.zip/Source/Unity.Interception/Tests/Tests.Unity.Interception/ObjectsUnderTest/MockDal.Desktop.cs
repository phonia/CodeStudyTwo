﻿using System;

namespace Microsoft.Practices.Unity.InterceptionExtension.Tests.ObjectsUnderTest
{
    public partial class MockDal : MarshalByRefObject
    {
    }
}
